#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re
import os
import sys
import time
from pathlib import Path

def process_large_html_file(input_file, output_file=None):
    """处理大型HTML文件 - 适用于411MB+的文件"""
    
    if not os.path.exists(input_file):
        print(f"错误: 输入文件 '{input_file}' 不存在")
        return
    
    # 自动生成输出文件名
    if output_file is None:
        input_path = Path(input_file)
        output_file = input_path.stem + "_search" + input_path.suffix
    
    print(f"开始处理文件: {input_file}")
    file_size = os.path.getsize(input_file)
    print(f"文件大小: {file_size / (1024*1024):.2f} MB")
    
    start_time = time.time()
    
    # 尝试不同的编码读取文件
    content = read_file_with_encodings(input_file)
    if content is None:
        print("错误: 无法读取文件，请检查文件编码")
        return
    
    print(f"文件读取完成，总长度: {len(content)} 字符")
    
    # 提取章节 - 使用更通用的模式
    chapters = extract_chapters(content)
    print(f"成功提取章节: {len(chapters)} 个")
    
    if len(chapters) == 0:
        print("警告: 未找到章节，将创建单章节文件")
        chapters = [(1, "全文内容", content[:100000])]  # 限制内容长度
    
    # 分配到区块
    blocks = distribute_to_blocks(chapters)
    
    # 生成HTML
    html_content = generate_search_html(blocks, len(chapters), input_file)
    
    # 写入文件
    try:
        with open(output_file, 'w', encoding='gbk') as f:
            f.write(html_content)
        
        output_size = os.path.getsize(output_file)
        processing_time = time.time() - start_time
        
        print("\n处理完成!")
        print(f"输出文件: {output_file}")
        print(f"输出大小: {output_size / 1024:.1f} KB")
        print(f"总章节: {len(chapters)} 章")
        print(f"处理时间: {processing_time:.1f} 秒")
        print(f"支持搜索关键词: 秦宝宝、秦泽、老爷子、王子衿等")
        
    except Exception as e:
        print(f"写入文件时出错: {e}")

def read_file_with_encodings(file_path):
    """尝试多种编码读取文件"""
    encodings = ['gbk', 'utf-8', 'gb2312', 'big5', 'latin1']
    
    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding, errors='ignore') as f:
                content = f.read()
            print(f"成功使用编码: {encoding}")
            return content
        except UnicodeDecodeError:
            continue
        except Exception as e:
            print(f"编码 {encoding} 读取失败: {e}")
            continue
    
    return None

def extract_chapters(content):
    """提取章节 - 使用通用模式"""
    chapters = []
    
    # 多种章节模式
    patterns = [
        r'第(\d+)章\s*([^\n<]*)',  # 第114章 标题
        r'第(\d+)回\s*([^\n<]*)',  # 第114回 标题
        r'第(\d+)节\s*([^\n<]*)',  # 第114节 标题
        r'Chapter\s*(\d+)\s*([^\n<]*)',  # Chapter 114 标题
        r'<h[12][^>]*>第(\d+)[章节][^<]*</h[12]>',  # HTML标题格式
    ]
    
    for pattern in patterns:
        matches = list(re.finditer(pattern, content))
        if len(matches) > 10:  # 如果找到足够多的章节
            print(f"使用模式找到 {len(matches)} 个章节: {pattern}")
            break
    else:
        # 如果没有找到章节，使用段落分割
        print("未找到标准章节，使用段落分割")
        return split_by_paragraphs(content)
    
    # 处理找到的章节
    for i, match in enumerate(matches):
        try:
            chapter_num = int(match.group(1))
            chapter_title = match.group(2).strip() if match.groups() > 1 else ""
            
            # 提取内容
            start_pos = match.end()
            if i < len(matches) - 1:
                end_pos = matches[i + 1].start()
            else:
                end_pos = len(content)
            
            chapter_content = content[start_pos:end_pos]
            
            # 清理内容
            clean_content = clean_html_content(chapter_content)
            
            title = f"第{chapter_num}章{chapter_title}" if chapter_title else f"第{chapter_num}章"
            chapters.append((chapter_num, title, clean_content))
            
        except Exception as e:
            continue
    
    return chapters

def split_by_paragraphs(content, max_chapters=100):
    """如果没有章节，按段落分割"""
    print("使用段落分割创建伪章节")
    paragraphs = re.split(r'\n\s*\n', content)
    chapters = []
    
    for i in range(min(len(paragraphs), max_chapters)):
        clean_content = clean_html_content(paragraphs[i])
        if len(clean_content.strip()) > 50:  # 只保留有内容的段落
            chapters.append((i+1, f"段落 {i+1}", clean_content))
    
    return chapters

def clean_html_content(content):
    """清理HTML内容"""
    if not content:
        return "内容为空"
    
    # 移除HTML标签但保留换行
    clean_content = re.sub(r'<script[^>]*>.*?</script>', '', content, flags=re.DOTALL)
    clean_content = re.sub(r'<style[^>]*>.*?</style>', '', clean_content, flags=re.DOTALL)
    clean_content = re.sub(r'<[^>]+>', ' ', clean_content)
    
    # 合并空白字符但保留段落结构
    clean_content = re.sub(r'\s+', ' ', clean_content)
    clean_content = clean_content.strip()
    
    return clean_content if clean_content else "本章节内容"

def distribute_to_blocks(chapters, num_blocks=26):
    """将章节分配到区块"""
    total_chapters = len(chapters)
    blocks = {}
    
    base_chapters = total_chapters // num_blocks
    extra_chapters = total_chapters % num_blocks
    
    start_idx = 0
    for i in range(num_blocks):
        letter = chr(65 + i)  # A-Z
        chunk_size = base_chapters
        if i < extra_chapters:
            chunk_size += 1
        
        end_idx = start_idx + chunk_size
        if end_idx > total_chapters:
            end_idx = total_chapters
        
        if start_idx < total_chapters:
            blocks[letter] = chapters[start_idx:end_idx]
            block_info = blocks[letter]
            print(f"区块 {letter}: 第{block_info[0][0]}-第{block_info[-1][0]}章 (共{len(block_info)}章)")
            start_idx = end_idx
    
    return blocks

def generate_search_html(blocks, total_chapters, original_filename):
    """生成搜索HTML"""
    
    # 导航条
    nav_links = []
    for i in range(26):
        letter = chr(65 + i)
        if letter in blocks and blocks[letter]:
            nav_links.append(f'<a href="#{letter.lower()}">{letter}</a>')
    nav_links.append('<a href="#0">↑顶部</a>')
    navigation = ' '.join(nav_links)
    
    # 内容区块
    content_blocks = []
    for letter in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
        if letter in blocks and blocks[letter]:
            section_chapters = blocks[letter]
            
            block_html = f'''
<div class="section">
    <h2 class="section-title" onclick="toggleSection('{letter.lower()}')">
        <a name="{letter.lower()}">【{letter}】区块 {letter}</a>
        <span class="chapter-count">第{section_chapters[0][0]}-{section_chapters[-1][0]}章 (共{len(section_chapters)}章) <span id="icon-{letter.lower()}">▼</span></span>
    </h2>
    <div class="section-content" id="c-{letter.lower()}">'''
            
            for chap_num, chap_title, chap_content in section_chapters:
                paragraphs = smart_split(chap_content)
                
                block_html += f'''
    <div class="chapter">
        <div class="chapter-header">{chap_title}</div>
        <div class="chapter-text">'''
                
                for i, para in enumerate(paragraphs):
                    para_id = f'p_{letter.lower()}_{chap_num}_{i}'
                    block_html += f'<p id="{para_id}" data-original="{escape_html(para)}">{para}</p>'
                
                block_html += '''
        </div>
    </div>'''
            
            block_html += f'''
        <div class="back-to-top">
            <a href="#0">↑ 返回顶部</a>
        </div>
    </div>
</div>'''
            
            content_blocks.append(block_html)
    
    # HTML模板
    html_template = f'''<!DOCTYPE html>
<html>
<head>
<meta charset="GBK">
<title>大型文件搜索版 - {original_filename}</title>
<style>
body {{
    font-family: "Microsoft YaHei", sans-serif;
    margin: 0;
    padding: 0;
    background: #f8f9fa;
    line-height: 1.6;
}}
.mark {{
    background: #ffeb3b !important;
    color: #000 !important;
    padding: 2px 4px;
    border-radius: 2px;
}}
.nav-bar {{
    position: sticky;
    top: 0;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    padding: 15px;
    z-index: 1000;
    text-align: center;
}}
.nav-bar a {{
    margin: 0 5px;
    text-decoration: none;
    color: white;
    font-weight: bold;
    padding: 5px 10px;
    border-radius: 4px;
}}
.search-box {{
    padding: 20px;
    background: white;
    border-bottom: 1px solid #e1e1e1;
}}
.search-box input {{
    width: 100%;
    padding: 15px;
    font-size: 16px;
    border: 2px solid #ddd;
    border-radius: 8px;
}}
.section {{
    margin: 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}}
.section-title {{
    background: #fff2e8;
    color: #d4380d;
    padding: 15px;
    margin: 0;
    cursor: pointer;
    border-left: 6px solid #ff6b35;
}}
.section-content {{
    padding: 20px;
}}
.chapter {{
    margin-bottom: 30px;
}}
.chapter-header {{
    color: #d4380d;
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 15px;
    border-bottom: 2px solid #ff6b35;
    padding-bottom: 5px;
}}
.chapter-text p {{
    margin-bottom: 15px;
    text-align: justify;
    text-indent: 2em;
}}
</style>
<script>
function searchContent() {{
    var query = document.getElementById('searchInput').value;
    var results = document.getElementById('searchStats');
    var allParagraphs = document.querySelectorAll('.chapter-text p');
    
    var foundCount = 0;
    
    // 重置所有高亮
    allParagraphs.forEach(function(p) {{
        var original = p.getAttribute('data-original');
        if (original) {{
            p.innerHTML = original;
        }}
    }});
    
    if (!query) {{
        results.innerHTML = '';
        results.style.display = 'none';
        return;
    }}
    
    // 搜索每个段落
    allParagraphs.forEach(function(p) {{
        var text = p.textContent || p.innerText;
        if (text.includes(query)) {{
            foundCount++;
            var newHTML = text.replace(new RegExp(escapeRegExp(query), 'g'), 
                                      '<mark class="mark">' + query + '</mark>');
            p.innerHTML = newHTML;
        }}
    }});
    
    results.innerHTML = '搜索 "' + query + '" 找到 ' + foundCount + ' 个结果';
    results.style.display = 'block';
}}

function escapeRegExp(string) {{
    return string.replace(/[.*+?^${{}}()|[\\]\\\\]/g, '\\\\$&');
}}

function toggleSection(id) {{
    var content = document.getElementById('c-' + id);
    var icon = document.getElementById('icon-' + id);
    if (content.style.display === 'none') {{
        content.style.display = 'block';
        icon.textContent = '▼';
    }} else {{
        content.style.display = 'none';
        icon.textContent = '▲';
    }}
}}

document.addEventListener('DOMContentLoaded', function() {{
    // 默认展开所有章节
    document.querySelectorAll('.section-content').forEach(function(el) {{
        el.style.display = 'block';
    }});
}});
</script>
</head>
<body>
<a name="0"></a>

<div style="background: #e3f2fd; padding: 15px; text-align: center; color: #1976d2;">
    <strong>大型文件搜索版 - {original_filename}</strong><br>
    <small>总章节: {total_chapters} 章 | 支持全文搜索</small>
</div>

<div class="nav-bar">
    {navigation}
</div>

<div class="search-box">
    <input type="text" id="searchInput" onkeyup="searchContent()" 
           placeholder="请输入关键词搜索...">
    <div id="searchStats" style="display: none; margin-top: 10px; padding: 10px; background: #4caf50; color: white; border-radius: 4px;"></div>
</div>

{''.join(content_blocks)}

</body>
</html>'''
    
    return html_template

def escape_html(text):
    """转义HTML特殊字符"""
    if not text:
        return ""
    return (text.replace('&', '&amp;')
               .replace('<', '&lt;')
               .replace('>', '&gt;')
               .replace('"', '&quot;'))

def smart_split(text, max_length=500):
    """智能文本分割"""
    if not text or len(text.strip()) == 0:
        return ["内容为空"]
    
    text = text.strip()
    if len(text) <= max_length:
        return [text]
    
    # 按句子分割
    sentences = re.split(r'[。！？!?]', text)
    paragraphs = []
    current_para = []
    current_length = 0
    
    for sentence in sentences:
        sentence = sentence.strip()
        if sentence:
            sentence_length = len(sentence)
            if current_length + sentence_length > max_length and current_para:
                para_text = '。'.join(current_para) + '。'
                paragraphs.append(para_text)
                current_para = [sentence]
                current_length = sentence_length
            else:
                current_para.append(sentence)
                current_length += sentence_length
    
    if current_para:
        para_text = '。'.join(current_para) + '。'
        paragraphs.append(para_text)
    
    return paragraphs if paragraphs else [text[:max_length] + "..."]

def main():
    """主函数"""
    if len(sys.argv) > 1:
        input_file = sys.argv[1]
        output_file = sys.argv[2] if len(sys.argv) > 2 else None
    else:
        # 如果没有参数，使用当前目录下的第一个htm/html文件
        html_files = list(Path('.').glob('*.htm')) + list(Path('.').glob('*.html'))
        if html_files:
            input_file = str(html_files[0])
            output_file = None
            print(f"自动选择文件: {input_file}")
        else:
            print("用法: python ds.py <输入文件> [输出文件]")
            print("或直接将文件拖放到此脚本上")
            input("按回车退出...")
            return
    
    process_large_html_file(input_file, output_file)

if __name__ == "__main__":
    main()