﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re
import os
import sys

# 修复Windows命令行编码问题
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')

def create_perfect_html():
    """完美版HTML生成器 - 修复所有问题"""
    
    # 使用GBK编码读取文件
    with open('u2.txt', 'r', encoding='gbk', errors='ignore') as f:
        content = f.read()
    
    print("文件总长度: " + str(len(content)) + " 字符")
    
    # 使用找到的114个章节
    pattern = r'第(\d+)章([^<]*)'
    matches = list(re.finditer(pattern, content))
    print("使用模式找到 " + str(len(matches)) + " 个章节")
    
    # 构建完整的114章
    chapters = []
    for i, match in enumerate(matches):
        try:
            chapter_num = int(match.group(1))
            chapter_title = match.group(2).strip()
            
            # 提取内容
            start_pos = match.end()
            if i < len(matches) - 1:
                end_pos = matches[i + 1].start()
            else:
                end_pos = len(content)
            
            chapter_content = content[start_pos:end_pos]
            
            # 清理内容
            chapter_content = re.sub(r'<[^>]+>', '', chapter_content)
            chapter_content = re.sub(r'\s+', ' ', chapter_content).strip()
            
            chapters.append((chapter_num, "第" + str(chapter_num) + "章" + chapter_title, chapter_content))
            
        except Exception as e:
            continue
    
    print("成功构建章节: " + str(len(chapters)) + " 个")
    
    # 分配到26个区块
    total_chapters = len(chapters)
    blocks = {}
    
    base_chapters = total_chapters // 26
    extra_chapters = total_chapters % 26
    
    start_idx = 0
    for i in range(26):
        letter = chr(65 + i)
        chunk_size = base_chapters
        if i < extra_chapters:
            chunk_size += 1
        
        end_idx = start_idx + chunk_size
        if end_idx > total_chapters:
            end_idx = total_chapters
        
        if start_idx < total_chapters:
            blocks[letter] = chapters[start_idx:end_idx]
            block_info = blocks[letter]
            print("区块 " + letter + ": 第" + str(block_info[0][0]) + "-第" + str(block_info[-1][0]) + "章 (共" + str(len(block_info)) + "章)")
            start_idx = end_idx
    
    # 生成HTML
    html_content = generate_perfect_html(blocks, total_chapters)
    
    # 写入文件
    output_file = 'xdpsk_perfect.htm'
    with open(output_file, 'w', encoding='gbk') as f:
        f.write(html_content)
    
    file_size = os.path.getsize(output_file)
    print("\n生成完成!")
    print("文件: " + output_file)
    print("大小: " + str(round(file_size/1024, 1)) + " KB")
    print("总章节: " + str(total_chapters) + "章")
    print("请在浏览器中打开查看完整内容")

def generate_perfect_html(blocks, total_chapters):
    """生成完美的HTML内容"""
    
    # 导航条
    nav_links = []
    for i in range(26):
        letter = chr(65 + i)
        nav_links.append('<a href="#' + letter.lower() + '">' + letter + '</a>')
    navigation = ' '.join(nav_links) + ' <a href="#0">↑顶部</a>'
    
    # 区块标题
    section_titles = {
        'A': '浮夸演唱', 'B': '秦泽教导', 'C': '身份曝光',
        'D': 'KTV风波', 'E': '姐弟互动', 'F': '老爷子震怒',
        'G': '家庭会议', 'H': '歌星总决赛', 'I': '大明良将',
        'J': '向天再借', 'K': '备战决赛', 'L': '股市投资',
        'M': '王子衿', 'N': '财政消费', 'O': '星艺内部',
        'P': '网络热梗', 'Q': '系统任务', 'R': '裴南曼',
        'S': '朋友圈', 'T': '明星成长', 'U': '音乐才华',
        'V': '家庭教育', 'W': '职场生活', 'X': '徐韵寒',
        'Y': '弟控情节', 'Z': '总决赛'
    }
    
    # 构建内容区块
    content_blocks = []
    for letter in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
        if letter in blocks and blocks[letter]:
            section_chapters = blocks[letter]
            section_title = section_titles.get(letter, "区块" + letter)
            
            block_html = '''
<div class="section">
    <h2 class="section-title" onclick="toggleSection('{letter}')">
        <a name="{letter}">【{letter}】{title}</a>
        <span class="chapter-count">第{first_chap}-{last_chap}章 (共{count}章)</span>
    </h2>
    <div class="section-content" id="c-{letter}">'''.format(
        letter=letter.lower(),
        title=section_title,
        first_chap=section_chapters[0][0],
        last_chap=section_chapters[-1][0],
        count=len(section_chapters)
    )
            
            for chap_num, chap_title, chap_content in section_chapters:
                paragraphs = smart_split(chap_content)
                
                block_html += '''
    <div class="chapter">
        <div class="chapter-header">{title}</div>
        <div class="chapter-text" data-original="{content}">'''.format(
            title=chap_title,
            content=chap_content.replace('"', '&quot;')
        )
                
                for para in paragraphs:
                    block_html += '<p>' + para + '</p>'
                
                block_html += '''
        </div>
    </div>'''
            
            block_html += '''
        <div class="back-to-top">
            <a href="#0">↑ 返回顶部</a>
        </div>
    </div>
</div>'''
            
            content_blocks.append(block_html)
    
    # 完整HTML模板
    html_template = '''<!DOCTYPE html>
<html>
<head>
<meta charset="GBK">
<title>秦宝宝与秦泽故事全集 - 完整版</title>
<style>
body {
    font-family: "Microsoft YaHei", sans-serif;
    margin: 0;
    padding: 0;
    background: #f8f9fa;
    line-height: 1.6;
}
.mark {
    background-color: #ffeb3b;
    padding: 2px 0;
}
.nav-bar {
    position: sticky;
    top: 0;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    padding: 15px;
    z-index: 1000;
    text-align: center;
    box-shadow: 0 2px 10px rgba(0,0,0,0.2);
}
.nav-bar a {
    margin: 0 5px;
    text-decoration: none;
    color: white;
    font-weight: bold;
    font-size: 14px;
    padding: 5px 10px;
    border-radius: 4px;
    transition: background 0.3s;
}
.nav-bar a:hover {
    background: rgba(255,255,255,0.2);
}
.search-box {
    padding: 20px;
    background: white;
    border-bottom: 1px solid #e1e1e1;
}
.search-box input {
    width: 100%;
    padding: 15px;
    font-size: 16px;
    border: 2px solid #ddd;
    border-radius: 8px;
    box-sizing: border-box;
}
.section {
    margin: 25px auto;
    max-width: 1200px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    overflow: hidden;
}
.section-title {
    background: linear-gradient(135deg, #fff2e8 0%, #ffe8d6 100%);
    color: #d4380d;
    padding: 20px;
    margin: 0;
    cursor: pointer;
    border-left: 6px solid #ff6b35;
    font-size: 18px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.section-content {
    padding: 30px;
}
.chapter {
    margin-bottom: 40px;
    padding-bottom: 30px;
    border-bottom: 2px dashed #e1e1e1;
}
.chapter:last-child {
    border-bottom: none;
}
.chapter-header {
    font-size: 20px;
    font-weight: bold;
    color: #d4380d;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 3px solid #ff6b35;
}
.chapter-text p {
    margin-bottom: 16px;
    text-align: justify;
    text-indent: 2em;
}
.back-to-top {
    text-align: center;
    margin-top: 30px;
    padding-top: 20px;
    border-top: 1px solid #eee;
}
.back-to-top a {
    color: #667eea;
    text-decoration: none;
    font-weight: bold;
    padding: 10px 20px;
    border: 2px solid #667eea;
    border-radius: 6px;
    transition: all 0.3s;
}
.back-to-top a:hover {
    background: #667eea;
    color: white;
}
.chapter-count {
    font-size: 14px;
    color: #666;
    background: rgba(255,255,255,0.7);
    padding: 4px 8px;
    border-radius: 4px;
}
.stats-bar {
    background: #e3f2fd;
    padding: 15px;
    text-align: center;
    color: #1976d2;
    font-size: 14px;
    border-bottom: 1px solid #bbdefb;
}
</style>
<script>
// 修复的搜索功能
function searchContent() {
    var query = document.getElementById('searchInput').value.trim().toLowerCase();
    var elements = document.querySelectorAll('.chapter-text');
    var resultCount = 0;
    
    elements.forEach(function(el) {
        var originalHTML = el.getAttribute('data-original') || el.innerHTML;
        
        if (!query) {
            el.innerHTML = originalHTML;
            return;
        }
        
        // 创建临时元素来获取纯文本
        var tempDiv = document.createElement('div');
        tempDiv.innerHTML = originalHTML;
        var textContent = tempDiv.textContent || tempDiv.innerText || '';
        
        if (textContent.toLowerCase().includes(query)) {
            resultCount++;
            // 高亮匹配的文本
            var regex = new RegExp('(' + query.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&') + ')', 'gi');
            el.innerHTML = originalHTML.replace(regex, '<mark class="mark">$1</mark>');
        } else {
            el.innerHTML = originalHTML;
        }
    });
    
    // 显示搜索结果
    var stats = document.getElementById('searchStats');
    if (query) {
        stats.textContent = '找到 ' + resultCount + ' 个匹配结果';
        stats.style.display = 'block';
    } else {
        stats.style.display = 'none';
    }
}

function toggleSection(id) {
    var content = document.getElementById('c-' + id);
    var icon = document.getElementById('icon-' + id);
    if (content.style.display === 'none') {
        content.style.display = 'block';
        icon.textContent = '▲';
    } else {
        content.style.display = 'none';
        icon.textContent = '▼';
    }
}

// 页面加载后默认展开所有章节
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.section-content').forEach(function(el) {
        el.style.display = 'block';
    });
});
</script>
</head>
<body>
<a name="0"></a>

<div class="stats-bar">
    完整故事内容 | 支持全文搜索 | 点击标题折叠章节
</div>

<div class="nav-bar">
    ''' + navigation + '''
</div>

<div class="search-box">
    <input type="text" id="searchInput" onkeyup="searchContent()" placeholder="输入关键词搜索全文内容...">
    <div id="searchStats" style="display: none; margin-top: 10px; color: #666; font-size: 14px;"></div>
</div>

''' + ''.join(content_blocks) + '''

</body>
</html>'''
    
    return html_template

def smart_split(text, max_length=300):
    """智能文本分割"""
    if not text:
        return []
    
    if len(text) <= max_length:
        return [text]
    
    # 按句子分割
    sentences = re.split(r'[。！？!?]', text)
    paragraphs = []
    current_para = []
    current_len = 0
    
    for sentence in sentences:
        sentence = sentence.strip()
        if sentence:
            current_para.append(sentence)
            current_len += len(sentence)
            
            if current_len >= max_length:
                para_text = '。'.join(current_para) + '。'
                paragraphs.append(para_text)
                current_para = []
                current_len = 0
    
    if current_para:
        para_text = '。'.join(current_para) + '。'
        paragraphs.append(para_text)
    
    return paragraphs

if __name__ == "__main__":
    create_perfect_html()